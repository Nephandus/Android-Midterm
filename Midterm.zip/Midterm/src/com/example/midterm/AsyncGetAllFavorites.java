/*Midterm
 *AsyncGetAllFavorites.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

public class AsyncGetAllFavorites extends AsyncTask<String, Void, ArrayList<String>>{
	ProgressDialog dialog;
	Activity parent;
	CustomAdapter moviesAdapter;
	ArrayList<String> moviesToGet = new ArrayList<String>();
	String error = "";
	ArrayList<Movie> movies = new ArrayList<Movie>();

	public AsyncGetAllFavorites(Activity activity, CustomAdapter adapter) {;
		parent = activity;
		dialog = new ProgressDialog(parent);
		moviesAdapter = adapter;
	}
	
	@Override
	protected void onPreExecute() {
		dialog.setMessage("Loading Movies");
		dialog.setCancelable(false);
		dialog.show();
	}
	
	@Override
	protected ArrayList<String> doInBackground(String... params) {
		android.os.Process.setThreadPriority(0);
		try {
			URL url = new URL("http://cci-webdev.uncc.edu/~mshehab/api-rest/favorites/getAllFavorites.php");
			
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setDoInput(true);
			con.setDoOutput(true);
			
			StringBuilder sbOut= new StringBuilder();
			sbOut.append(URLEncoder.encode("uid", "UTF-8"));
		    sbOut.append("=");
		    sbOut.append(URLEncoder.encode(params[0], "UTF-8"));
			
			OutputStream os = con.getOutputStream();
			
			BufferedWriter writer = new BufferedWriter(
			        new OutputStreamWriter(os, "UTF-8"));
			writer.write(sbOut.toString());
			writer.close();
			os.close();
			
			int statusCode = con.getResponseCode();
			Log.d("demo", "getAllFavorites:statusCode="+statusCode);
			if (statusCode == HttpURLConnection.HTTP_OK) {
				InputStream in = con.getInputStream();
				XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
				parser.setInput(in, "UTF-8");
				int event = parser.getEventType();
				
				ArrayList<String> movieIds = new ArrayList<String>();
				int count = 0;
				
				while(event != XmlPullParser.END_DOCUMENT){
					if (event == XmlPullParser.TEXT) {
						movieIds.add(parser.getText());
							count++;
						if(! movieIds.get(0).equals("0") && count == 3) {
							error = movieIds.get(1);
						} else if (count == 3){
							movieIds.clear();
						}
					}
					event = parser.next();
				}
				return movieIds;
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(ArrayList<String> result) {
		if (! result.equals(null)){
			if (! error.equals("")) {
			Toast.makeText(parent, error, Toast.LENGTH_LONG).show();
			}
		}
		moviesToGet.addAll(result);
		for(String s : moviesToGet){
			new AsyncMovieGet(moviesAdapter).execute(s);
		}
		dialog.dismiss();
	}
}
