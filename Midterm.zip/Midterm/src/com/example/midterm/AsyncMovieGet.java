/*Midterm
 *AsyncMovieGet.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;

import android.os.AsyncTask;
import android.util.Log;

public class AsyncMovieGet extends AsyncTask<String, Void, Movie>{
	CustomAdapter moviesAdapter;
	HttpClient client = new DefaultHttpClient();

	public AsyncMovieGet(CustomAdapter adapter) {
		moviesAdapter = adapter;
	}
	
	@Override
	protected Movie doInBackground(String... params) {
		android.os.Process.setThreadPriority(-20);
		try {
			URL url = new URL("http://api.rottentomatoes.com/api/public/v1.0/movies/"+params[0]+".json?apikey=2smsxdgftgqe9nvpa8xvah8b");
			android.os.Process.setThreadPriority(-20);
			
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.connect();			
			int statusCode = con.getResponseCode();
			if (statusCode != 200) {
				Log.d("demo", "moviesGet:statusCode="+statusCode);
			}
			if (statusCode == HttpURLConnection.HTTP_OK) {				
				BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = reader.readLine();
				while (line != null) {
					sb.append(line);
					line = reader.readLine();
				}
				Movie movie = MovieUtil.MovieJSONParser.parseMovie(sb.toString());
				return movie;
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(Movie result) {
		moviesAdapter.add(result);
	}
}
