/*Midterm
 *AsyncGenresGet.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

public class AsyncGenresGet extends AsyncTask<Movie, Void, String> {
	TextView genresView;
	int statusCode;
	String genres;
	
	public AsyncGenresGet(TextView textView) {
		genresView = textView;
	}
	
	@Override
	protected String doInBackground(Movie... params) {
		android.os.Process.setThreadPriority(-20);
		String urlString = "http://api.rottentomatoes.com/api/public/v1.0/movies/"+params[0].getId()+".json?apikey=2smsxdgftgqe9nvpa8xvah8b";
		try {
			URL url = new URL(urlString);			
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.connect();			
			statusCode = con.getResponseCode();
			if (statusCode == HttpURLConnection.HTTP_OK) {		
				BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = reader.readLine();
				while (line != null) {
					sb.append(line);
					line = reader.readLine();
				}
				JSONObject genresJSONObject =(new JSONObject(sb.toString()));
				genres = genresJSONObject.getString("genres");
				return genres;
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(String result) {
		try {
			String stringFormatting = result;
			stringFormatting = stringFormatting.substring(2,stringFormatting.length()-2);
			String[] stringParts = stringFormatting.split("\",\"");
			if (stringParts.length > 1) {
				stringFormatting ="";
				
				for(String i : stringParts) {
					stringFormatting= stringFormatting + i+", ";
				}
				stringFormatting = stringFormatting.substring(0,stringFormatting.length()-2);
			}
			genresView.setText(stringFormatting);
			genresView.postInvalidate();
		} catch (NullPointerException e) {
			Log.d("demo", "genre:statusCode="+statusCode);
		}
	}
}
