/*Midterm
 *AsyncMoviesGet.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;

public class AsyncMoviesGet extends AsyncTask<String, Void, ArrayList<Movie>>{
	ProgressDialog dialog;
	CustomAdapter moviesAdapter;
	HttpClient client = new DefaultHttpClient();

	public AsyncMoviesGet(Activity parent, CustomAdapter adapter) {
		dialog = new ProgressDialog(parent);
		moviesAdapter = adapter;
	}
	
	@Override
	protected void onPreExecute() {
		dialog.setMessage("Loading Movies");
		dialog.setCancelable(false);
		dialog.show();
	}
	
	@Override
	protected ArrayList<Movie> doInBackground(String... params) {
		android.os.Process.setThreadPriority(-10);
		String urlString = params[0];
		try {
			URL url = new URL(urlString);			
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.connect();			
			int statusCode = con.getResponseCode();
			Log.d("demo", "moviesGet:statusCode="+statusCode);
			if (statusCode == HttpURLConnection.HTTP_OK) {				
				BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = reader.readLine();
				while (line != null) {
					sb.append(line);
					line = reader.readLine();
				}
				ArrayList<Movie> movies = MovieUtil.MoviesJSONParser.parseMovies(sb.toString());
				return movies;
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(ArrayList<Movie> result) {
		dialog.dismiss();
		moviesAdapter.addAll(result);
	}
}
