/*Midterm
 *Movie.java
 *Lonnie Gainey*/

package com.example.midterm;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {
	String id, title, year, runtime, theaterRelease, mpaaRating, thumb, poster, criticsScore, criticsRating,
	audienceScore, audienceRating, link;

	public Movie(JSONObject movieJSONObject) throws JSONException{
		this.id = movieJSONObject.getString("id");
		this.title = movieJSONObject.getString("title");
		this.year = movieJSONObject.getString("year");
		this.runtime = movieJSONObject.getString("runtime");
		JSONObject releaseDatesJSONObject = (new JSONObject(movieJSONObject.getString("release_dates")));
		try {
			this.theaterRelease = releaseDatesJSONObject.getString("theater");
		} catch (JSONException e) {
			this.theaterRelease = "No theater release";
			e.printStackTrace();
		}
		this.mpaaRating = movieJSONObject.getString("mpaa_rating");
		JSONObject postersJSONObject = (new JSONObject(movieJSONObject.getString("posters")));
		this.thumb = postersJSONObject.getString("thumbnail");
		this.poster = postersJSONObject.getString("detailed");
		JSONObject ratingsJSONObject = (new JSONObject(movieJSONObject.getString("ratings")));
		this.criticsScore = ratingsJSONObject.getString("critics_score");
		try {
			this.criticsRating = ratingsJSONObject.getString("critics_rating");
		}catch(JSONException e) {
			this.criticsRating = "Not Ranked";
		}
        this.audienceScore = ratingsJSONObject.getString("audience_score");
        try {
        	this.audienceRating = ratingsJSONObject.getString("audience_rating");
        } catch (JSONException e) {
			this.audienceRating = "Not Ranked";
		}
        JSONObject linksJSONObject = (new JSONObject(movieJSONObject.getString("links")));
        this.link = linksJSONObject.getString("alternate");
	}
	
	public Movie(Parcel in) {
		String[] data = new String[13];

        in.readStringArray(data);
        this.id = data[0];
        this.title = data[1];
        this.year = data[2];
        this.runtime = data[3];
        this.theaterRelease = data[4];
        this.mpaaRating = data[5];
        this.thumb = data[6];
        this.poster = data[7];
        this.criticsScore = data[8];
        this.criticsRating = data[9];
        this.audienceScore = data[10];
        this.audienceRating = data[11];
        this.link = data[12];
	}

	public Movie() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getYear() {
		return year;
	}
	
	public void setYear(String year) {
		this.year = year;
	}
	
	public String getRuntime() {
		return runtime;
	}

	public void setRuntime(String runtime) {
		this.runtime = runtime;
	}
	
	public String getTheaterRelease() {
		return theaterRelease;
	}

	public void setTheaterRelease(String theaterRelease) {
		this.theaterRelease = theaterRelease;
	}
	
	public String getMpaaRating() {
		return mpaaRating;
	}

	public void setMpaaRating(String mpaaRating) {
		this.mpaaRating = mpaaRating;
	}
	
	public String getThumb() {
		return thumb;
	}
	
	public void setThumb(String thumb) {
		this.thumb = thumb;
	}
	
	public String getPoster() {
		return poster;
	}
	
	public void setPoster(String poster) {
		this.poster = poster;
	}
	
	public String getCriticsScore() {
		return criticsScore;
	}
	
	public void setCriticsScore(String criticsScore) {
		this.criticsScore = criticsScore;
	}
	
	public String getCriticsRating() {
		return criticsRating;
	}
	
	public void setCriticsRating(String criticsRating) {
		this.criticsRating = criticsRating;
	}
	
	public String getAudienceRating() {
		return audienceRating;
	}
	
	public void setAudienceRating(String audienceRating) {
		this.audienceRating = audienceRating;
	}
	
	public String getAudienceScore() {
		return audienceScore;
	}
	
	public void setAudienceScore(String audienceScore) {
		this.audienceScore = audienceScore;
	}
	
	public String getLink() {
		return link;
	}
	
	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public String toString() {
		return thumb+" "+title+" "+year+" "+mpaaRating+" "+criticsRating+" "+audienceRating;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeStringArray(new String[] {
		        this.id,
				this.title,
				this.year,
				this.runtime,
				this.theaterRelease,
				this.mpaaRating,
				this.thumb,
				this.poster,
				this.criticsScore,
				this.criticsRating,
				this.audienceScore,
				this.audienceRating,
				this.link
		});		
	}
	
    public static final Parcelable.Creator<Movie> CREATOR = new Parcelable.Creator<Movie>() {
        public Movie createFromParcel(Parcel in) {
            return new Movie(in); 
        }

        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };
}

