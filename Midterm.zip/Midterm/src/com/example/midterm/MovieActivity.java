/*Midterm
 *MovieActivity.java
 *Lonnie Gainey*/

package com.example.midterm;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MovieActivity extends Activity {
	Bundle b;
	Movie movie;
	ToggleButton favoriteStar;
	Boolean favorites;
	int position;
	SharedPreferences settings;
	SharedPreferences.Editor editor;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_movie);
		
		b = getIntent().getExtras();
		movie = b.getParcelable("movie");
		position = b.getInt("position");
		favorites = b.getBoolean("favorites");
		
		
		settings = getSharedPreferences("deleted", -1);
		editor = settings.edit();
		
		final ImageView moviePoster = (ImageView) findViewById(R.id.moviePosterView);
		TextView genres = (TextView) findViewById(R.id.genresView);
		favoriteStar = (ToggleButton)findViewById(R.id.favoriteStar);
		favoriteStar.setBackgroundResource(android.R.drawable.btn_star_big_off);
//AsyncIsFavorite accesses the currently non-existent site of the teacher.
//		new AsyncIsFavorite(this, favoriteStar).execute(Config.getUid(), movie.getId());
		new AsyncGenresGet(genres).execute(movie);
		new AsyncImageGet(moviePoster).execute(movie);
		
		TextView movieTitle = (TextView) findViewById(R.id.movieTitleView);
		movieTitle.setText(movie.getTitle());
		
		TextView releaseDate = (TextView) findViewById(R.id.releaseDateView);
		if (movie.getTheaterRelease().equals("No theater release")){
			releaseDate.setText(movie.getTheaterRelease());
		} else {
			String dateFormatting = movie.getTheaterRelease();
			String[] dateParts = dateFormatting.split("-");
			dateFormatting = dateParts[1]+"/"+dateParts[2]+"/"+dateParts[0];
			releaseDate.setText(dateFormatting);
		}
		
		TextView mpaaRating = (TextView) findViewById(R.id.mpaaRatingView);
		mpaaRating.setText(movie.getMpaaRating());
		
		TextView runtime = (TextView) findViewById(R.id.runtimeView);
		if (! movie.getRuntime().equals("")) {
			int timeFormatting = Integer.valueOf(movie.getRuntime());
			int hours = timeFormatting / 60;
			int minutes = timeFormatting % 60;
			runtime.setText(hours+" hr. "+minutes+" min.");
		}
		
		TextView criticsScore = (TextView) findViewById(R.id.criticsScoreView);
		criticsScore.setText(movie.getCriticsScore()+"%");
		
    	ImageView criticsRating = (ImageView) findViewById(R.id.criticsRatingView);
    	String criticsRatingTest = movie.getCriticsRating();
		if(criticsRatingTest.equals("Certified Fresh")) { 
			criticsRating.setImageResource(R.drawable.certified_fresh);
		}else if(criticsRatingTest.equals("Fresh")) {
			criticsRating.setImageResource(R.drawable.fresh);
		}else if(criticsRatingTest.equals("Upright")) {
			criticsRating.setImageResource(R.drawable.upright);
		}else if(criticsRatingTest.equals("Not Ranked")) {
			criticsRating.setImageResource(R.drawable.notranked);
		}else if(criticsRatingTest.equals("Spilled")) {
			criticsRating.setImageResource(R.drawable.spilled);
		}else if(criticsRatingTest.equals("Rotten")) {
			criticsRating.setImageResource(R.drawable.rotten);
		}
		
		TextView audienceScore = (TextView) findViewById(R.id.audienceScoreView);
		audienceScore.setText(movie.getAudienceScore()+"%");
		
		ImageView audienceRating = (ImageView) findViewById(R.id.audienceRatingView);
		String audienceRatingTest = movie.getAudienceRating();
		if(audienceRatingTest.equals("Certified Fresh")) { 
			audienceRating.setImageResource(R.drawable.certified_fresh);
		}else if(audienceRatingTest.equals("Fresh")) {
			audienceRating.setImageResource(R.drawable.fresh);
		}else if(audienceRatingTest.equals("Upright")) {
			audienceRating.setImageResource(R.drawable.upright);
		}else if(audienceRatingTest.equals("Not Ranked")) {
			audienceRating.setImageResource(R.drawable.notranked);
		}else if(audienceRatingTest.equals("Spilled")) {
			audienceRating.setImageResource(R.drawable.spilled);
		}else if(audienceRatingTest.equals("Rotten")) {
			audienceRating.setImageResource(R.drawable.rotten);
		}
		
		ImageButton movieBackButton = (ImageButton)findViewById(R.id.movieBackButton);
		movieBackButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				finish();
				moviePoster.setImageResource(R.drawable.poster_not_found);
			}
			
		});
		
		ImageButton webPageButton = (ImageButton)findViewById(R.id.webPageButton);
		webPageButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Uri url = Uri.parse(movie.getLink());
				Intent browser = new Intent(Intent.ACTION_VIEW, url);
				startActivity(browser);
			}
			
		});

		favoriteStar.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (! favoriteStar.isChecked()) {
//AsyncDeleteFavorite accesses the currently non-existent site of the teacher.
//					new AsyncDeleteFavorite(MovieActivity.this).execute(Config.getUid(), movie.getId());
					if (favorites) {
						editor.putInt("deleted", position);
						editor.commit();
					}
					favoriteStar.setBackgroundResource(android.R.drawable.btn_star_big_off);
					favoriteStar.invalidate();
				}
				if (favoriteStar.isChecked()) {
//AsyncAddToFavorites accesses the currently non-existent site of the teacher.					
//					new AsyncAddToFavorites(MovieActivity.this).execute(Config.getUid(), movie.getId());
					if (favorites) {
						editor.putInt("deleted", -1);
						editor.commit();
					}
					favoriteStar.setBackgroundResource(android.R.drawable.btn_star_big_on);
					favoriteStar.invalidate();
				}
			}
			
		});
	}
}
