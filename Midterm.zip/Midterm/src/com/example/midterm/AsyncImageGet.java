/*Midterm
 *AsyncPosterGet.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

public class AsyncImageGet extends AsyncTask<Movie, Void, Bitmap> {
	ImageView posterView;
	int statusCode;
	Bitmap image;
	
	public AsyncImageGet(ImageView imageView) {
		posterView = imageView;
	}
	
	@Override
	protected Bitmap doInBackground(Movie... params) {
		android.os.Process.setThreadPriority(-20);
		String urlString = params[0].getPoster();
		try {
			URL url = new URL(urlString);			
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.connect();			
			statusCode = con.getResponseCode();
			if (statusCode == HttpURLConnection.HTTP_OK) {
				image = BitmapFactory.decodeStream(con.getInputStream());
				return image;
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(Bitmap result) {
		try {
			posterView.setImageBitmap(image);
			posterView.postInvalidate();
		} catch (NullPointerException e) {
			Log.d("demo", "image:statusCode="+statusCode);
		}
	}
}
