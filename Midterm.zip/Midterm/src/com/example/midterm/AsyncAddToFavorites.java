/*Midterm
 *AsyncAddToFavorites.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

public class AsyncAddToFavorites extends AsyncTask<String, Void, ArrayList<String>>{
	Activity parent;

	public AsyncAddToFavorites(Activity activity) {
		parent = activity;
	}

	@Override
	protected ArrayList<String> doInBackground(String... params) {
		try {
			URL url = new URL("http://cci-webdev.uncc.edu/~mshehab/api-rest/favorites/addToFavorites.php");
			android.os.Process.setThreadPriority(-20);
			
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setDoInput(true);
			con.setDoOutput(true);
			
			StringBuilder sbOut = new StringBuilder();
			sbOut.append(URLEncoder.encode("uid", "UTF-8"));
		    sbOut.append("=");
		    sbOut.append(URLEncoder.encode(params[0], "UTF-8"));
		    sbOut.append("&");
		    sbOut.append(URLEncoder.encode("mid", "UTF-8"));
		    sbOut.append("=");
		    sbOut.append(URLEncoder.encode(params[1], "UTF-8"));
		    
			OutputStream os = con.getOutputStream();
			
			BufferedWriter writer = new BufferedWriter(
			        new OutputStreamWriter(os, "UTF-8"));
			writer.write(sbOut.toString());
			writer.close();
			os.close();
			
			int statusCode = con.getResponseCode();
			Log.d("demo", "addToFavorites:statusCode="+statusCode);
			if (statusCode == HttpURLConnection.HTTP_OK) {
				InputStream in = con.getInputStream();
				XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
				parser.setInput(in, "UTF-8");
				int event = parser.getEventType();		
				
				ArrayList<String> response = new ArrayList<String>();
				
				while(event != XmlPullParser.END_DOCUMENT){
					if (event == XmlPullParser.TEXT) {
						response.add(parser.getText());
					}
					event = parser.next();
				}
				return response;
				
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(ArrayList<String> result) {
		if(! result.get(0).equals("0")) {
			Toast.makeText(parent, result.get(1), Toast.LENGTH_LONG).show();
		}
	}	
}