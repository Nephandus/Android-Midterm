/*Midterm
 *MainActivity.java
 *Lonnie Gainey*/

package com.example.midterm;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;


/*The url's should show all non-"My Favorite" requests are set to 50. A log.d's still set to show how many
 * are actually received from Rotten. The AsyncTasks have status code log.d's though thumbGet and PosterGet's
 * normally won't go off since that'd be spammy. At the risk of sounding incompetent, there are two things I
 * don't get. 1)The togglebutton's clicklistener tests in MovieActiviy seemed to be reverse, but they only work
 * like they are here for me. 2)isFavorite's XML text elements give back 2 whitespaces, when the other server
 * accesses don't, and, as with the oddly working togglebutton, the current result.get(6) here gives me the
 * true/false. I'm not sure of your efficiency or style grading, but everything here at least functions for me.
 * There is some weird exchange/email thing the emulator does on it's own that can mess with downloading things
 * I'm assuming you know more about what that is than I do, and that I didn't do it.*/
public class MainActivity extends Activity {
	//These (settings/editor) are for passing a "My Favorite"'s deleted favorite back from MovieActivity to
	//MoviesActivity. It occurred to me any restart that bypasses the reset in MoviesActivity would retain
	//the old id. This causes a null exception since it'll try to delete it any time you start MoviesActivity.
	//This, of course, would perpetuate until the retained data was wiped since the reset in MoviesActivity
	//would never be reached, due to always crashing just before. They were about the only weird parts for
	//their context, thus this lengthy explanation.
	SharedPreferences settings;
	SharedPreferences.Editor editor;

	ListView mainListView;
	String[] mainOptions = {
			"My Favorite Movies","Box Office Movies","In Theaters Movies","Opening Movies","Upcoming Movies"};
	ArrayAdapter<String> mainAdapter;
	String moviesJSONUrl;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		settings = getSharedPreferences("deleted", -1);
		editor = settings.edit();
		editor.putInt("deleted", -1);
		editor.commit();
		
		mainListView = (ListView) findViewById(R.id.mainListView);
		mainAdapter = new ArrayAdapter<String>(this, R.layout.custom_textview, mainOptions);
		mainListView.setAdapter(mainAdapter);

		mainListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent i = new Intent(getBaseContext(), MoviesActivity.class);
				switch (position) {
				case 0:
					moviesJSONUrl = "Favorites";
					break;
				case 1:
					moviesJSONUrl = "http://api.rottentomatoes.com/api/public/v1.0/lists/movies/box_office.json?apikey=2smsxdgftgqe9nvpa8xvah8b&limit=50";
					break;
				case 2:
					moviesJSONUrl = "http://api.rottentomatoes.com/api/public/v1.0/lists/movies/in_theaters.json?apikey=2smsxdgftgqe9nvpa8xvah8b&page_limit=50";
					break;
				case 3:
					moviesJSONUrl = "http://api.rottentomatoes.com/api/public/v1.0/lists/movies/opening.json?apikey=2smsxdgftgqe9nvpa8xvah8b&limit=50";
					break;
				case 4:
					moviesJSONUrl = "http://api.rottentomatoes.com/api/public/v1.0/lists/movies/upcoming.json?apikey=2smsxdgftgqe9nvpa8xvah8b&page_limit=50";
					break;
				}
				i.putExtra("moviesJSONUrl", moviesJSONUrl);
				startActivity(i);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) {
		case R.id.clearAllFavorties:
////AsyncDeleteAllFavorite accesses the currently non-existent site of the teacher.
//			new AsyncDeleteAllFavorites(this).execute(Config.getUid());
			break;
		case R.id.exit:
			this.finish();
			break;
		}
		return true;
	}
}
