/*Midterm
 *MoviesActivity.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class MoviesActivity extends Activity{

	ListView moviesListView;
	ArrayList<Movie> moviesOptions = new ArrayList<Movie>();
	CustomAdapter moviesAdapter;
	String moviesJSONUrl;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_movies);
		
		moviesListView = (ListView) findViewById(R.id.moviesListView);
		moviesAdapter = new CustomAdapter(this, R.layout.customview, moviesOptions);
		moviesListView.setAdapter(moviesAdapter);
		
		moviesJSONUrl = getIntent().getStringExtra("moviesJSONUrl");
		if (moviesJSONUrl.equals("Favorites")) {
////AsyncGetAllFavorite accesses the currently non-existent site of the teacher.			
//			new AsyncGetAllFavorites(this, moviesAdapter).execute(Config.getUid());
		}
		else {
			new AsyncMoviesGet(this, moviesAdapter).execute(moviesJSONUrl);
		}
		
	    moviesListView.setOnItemLongClickListener(new OnItemLongClickListener() {

	        @Override
	        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
	        	if (moviesJSONUrl.equals("Favorites")) {
////AsyncDeleteFavorite accesses the currently non-existent site of the teacher.	        		
//	        		new AsyncDeleteFavorite(MoviesActivity.this).execute(Config.getUid(), moviesAdapter.delete(position));
	        	}
	            return true;
	        }
	    });
		
		moviesListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent i = new Intent(getBaseContext(), MovieActivity.class);
				i.putExtra("movie", moviesOptions.get(position));
				i.putExtra("position", position);
				i.putExtra("favorites", true);
				startActivity(i);
			}
		});
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		SharedPreferences settings = getSharedPreferences("deleted", -1);
		SharedPreferences.Editor editor = settings.edit();
		Log.d("demo", settings.getInt("deleted", -1)+"");
		if (settings.getInt("deleted", -1) != -1) {
			moviesAdapter.delete(settings.getInt("deleted", 0));
		}
		editor.putInt("deleted", -1);
		editor.commit();
	}
}
