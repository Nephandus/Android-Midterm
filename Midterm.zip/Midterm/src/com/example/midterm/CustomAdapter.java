/*Midterm
 *CustomAdapter.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends ArrayAdapter<Movie> {
	Context mContext;

        private ArrayList<Movie> movieOptions;

        public CustomAdapter(Context context, int textViewResourceId, ArrayList<Movie> movieOptions) {
                super(context, textViewResourceId, movieOptions);
                this.movieOptions = movieOptions;
                mContext = context;
        }
        
        public String delete(int index) {
        	String id = movieOptions.get(index).getId();
        	this.remove(movieOptions.get(index));
        	return id;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
                View view = convertView;
                if (view == null) {
                    LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    view = inflater.inflate(R.layout.customview, null);
                }
                Movie movie = movieOptions.get(position);
                if (! movie.equals(null)) {
                	ImageView thumb = (ImageView) view.findViewById(R.id.thumbIcon);
                	new AsyncImageGet(thumb).execute(movie);
                	
                	TextView title = (TextView) view.findViewById(R.id.titleTextView);
                	title.setText(movie.getTitle());
                	
                	TextView year = (TextView) view.findViewById(R.id.yearTextView);
                	year.setText(movie.getYear());
                	
                	TextView mpaa = (TextView) view.findViewById(R.id.mpaaTextView);                              
                	mpaa.setText(movie.getMpaaRating());
                	
                	ImageView criticsRating = (ImageView) view.findViewById(R.id.criticsIcon);
                	String criticsRatingTest = movie.getCriticsRating();
            		if(criticsRatingTest.equals("Certified Fresh")) { 
            			criticsRating.setImageResource(R.drawable.certified_fresh);
            		}else if(criticsRatingTest.equals("Fresh")) {
            			criticsRating.setImageResource(R.drawable.fresh);
            		}else if(criticsRatingTest.equals("Upright")) {
            			criticsRating.setImageResource(R.drawable.upright);
            		}else if(criticsRatingTest.equals("Not Ranked")) {
            			criticsRating.setImageResource(R.drawable.notranked);
            		}else if(criticsRatingTest.equals("Spilled")) {
            			criticsRating.setImageResource(R.drawable.spilled);
            		}else if(criticsRatingTest.equals("Rotten")) {
            			criticsRating.setImageResource(R.drawable.rotten);
            		}
            		
            		ImageView audienceRating = (ImageView) view.findViewById(R.id.audienceIcon);
            		String audienceRatingTest = movie.getAudienceRating();
            		if(audienceRatingTest.equals("Certified Fresh")) { 
            			audienceRating.setImageResource(R.drawable.certified_fresh);
            		}else if(audienceRatingTest.equals("Fresh")) {
            			audienceRating.setImageResource(R.drawable.fresh);
            		}else if(audienceRatingTest.equals("Upright")) {
            			audienceRating.setImageResource(R.drawable.upright);
            		}else if(audienceRatingTest.equals("Not Ranked")) {
            			audienceRating.setImageResource(R.drawable.notranked);
            		}else if(audienceRatingTest.equals("Spilled")) {
            			audienceRating.setImageResource(R.drawable.spilled);
            		}else if(audienceRatingTest.equals("Rotten")) {
            			audienceRating.setImageResource(R.drawable.rotten);
            		}
                }
                return view;
        }
}
