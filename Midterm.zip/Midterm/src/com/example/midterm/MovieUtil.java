/*Midterm
 *MovieUtil.java
 *Lonnie Gainey*/

package com.example.midterm;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.util.Log;

public class MovieUtil {	
	static public class MoviesJSONParser{

		static ArrayList<Movie> parseMovies(String jsonString) throws JSONException{
			ArrayList<Movie> movies = new ArrayList<Movie>();
			JSONArray moviesJS = (new JSONObject(jsonString))			
					.getJSONArray("movies");
			for(int i=0; i<moviesJS.length(); i++){
				JSONObject movieJSONObject = moviesJS.getJSONObject(i);
				Movie movie = new Movie(movieJSONObject);
				movies.add(movie);
			}
			Log.d("demo", "Movies="+movies.size()+"");
			return movies;
		}
	}
	
	static public class MovieJSONParser{

		static Movie parseMovie(String jsonString) throws JSONException{
			Movie movie = new Movie();
			movie = new Movie(new JSONObject(jsonString));
			return movie;
		}
	}
	
	static public class MoviesXMLPullParser {
		static ArrayList<Movie> parseMovies(InputStream xmlIn) throws XmlPullParserException, NumberFormatException, IOException{						
			XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
			parser.setInput(xmlIn, "UTF-8");
			Movie movie = null;
			ArrayList<Movie> movies = null;
			int event = parser.getEventType();			
			while(event != XmlPullParser.END_DOCUMENT){
				switch (event) {
				case XmlPullParser.START_DOCUMENT:
					movies = new ArrayList<Movie>();
					break;
				case XmlPullParser.START_TAG:
					if(parser.getName().equals("movies")){
						movie = new Movie();
						movie.setId(parser.getAttributeValue(null, "id").trim());
					} else if(parser.getName().equals("age")){
						movie.setTitle(parser.nextText().trim());
					}
					break;
				case XmlPullParser.END_TAG:
					if(parser.getName().equals("movies")){
						movies.add(movie);
					}
				default:
					break;
				}
				event = parser.next();
			}
			return movies;
		}
	}
}